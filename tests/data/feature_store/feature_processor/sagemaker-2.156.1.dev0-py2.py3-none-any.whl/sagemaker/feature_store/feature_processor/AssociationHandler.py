# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import logging
from typing import List, Optional, Iterator
from botocore.exceptions import ClientError

from sagemaker import Session
from sagemaker.feature_store.feature_processor.lineage._feature_group_contexts import FeatureGroupContexts
from sagemaker.feature_store.feature_processor._constants import VALIDATION_EXCEPTION
from sagemaker.lineage import artifact, association
from sagemaker.lineage._api_types import AssociationSummary

logger = logging.getLogger("sagemaker")


class AssociationHandler:
    @staticmethod
    def add_upstream_feature_group_data_associations(
            feature_group_inputs: List[FeatureGroupContexts],
            pipeline_context_arn: str,
            pipeline_versions_context_arn: str,
            sagemaker_session: Session
    ):
        for feature_group in feature_group_inputs:
            AssociationHandler._add_associations(
                source_arn=feature_group.pipeline_context_arn,
                destination_arn=pipeline_context_arn,
                association_type="ContributedTo",
                sagemaker_session=sagemaker_session
            )
            AssociationHandler._add_associations(
                source_arn=feature_group.pipeline_version_context_arn,
                destination_arn=pipeline_versions_context_arn,
                association_type="ContributedTo",
                sagemaker_session=sagemaker_session
            )

    @staticmethod
    def add_upstream_raw_data_associations(
            raw_data_inputs: List[artifact.Artifact],
            pipeline_context_arn: str,
            pipeline_versions_context_arn: str,
            sagemaker_session: Session
    ):
        for raw_data_artifact in raw_data_inputs:
            AssociationHandler._add_associations(
                source_arn=raw_data_artifact.artifact_arn,
                destination_arn=pipeline_context_arn,
                association_type="ContributedTo",
                sagemaker_session=sagemaker_session
            )
            AssociationHandler._add_associations(
                source_arn=raw_data_artifact.artifact_arn,
                destination_arn=pipeline_versions_context_arn,
                association_type="ContributedTo",
                sagemaker_session=sagemaker_session
            )

    @staticmethod
    def add_upstream_transformation_code_associations(
            transformation_code_artifact: artifact.Artifact,
            pipeline_versions_context_arn: str,
            sagemaker_session: Session
    ):
        AssociationHandler._add_associations(
            source_arn=transformation_code_artifact.artifact_arn,
            destination_arn=pipeline_versions_context_arn,
            association_type="ContributedTo",
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def add_downstream_feature_group_data_associations(
            feature_group_output: FeatureGroupContexts,
            pipeline_context_arn: str,
            pipeline_versions_context_arn: str,
            sagemaker_session: Session
    ):
        AssociationHandler._add_associations(
            source_arn=pipeline_context_arn,
            destination_arn=feature_group_output.pipeline_context_arn,
            association_type="ContributedTo",
            sagemaker_session=sagemaker_session
        )
        AssociationHandler._add_associations(
            source_arn=pipeline_versions_context_arn,
            destination_arn=feature_group_output.pipeline_version_context_arn,
            association_type="ContributedTo",
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def add_pipeline_and_pipeline_version_association(
            pipeline_context_arn: str,
            pipeline_version_context_arn: str,
            sagemaker_session: Session
    ):
        AssociationHandler._add_associations(
            source_arn=pipeline_context_arn,
            destination_arn=pipeline_version_context_arn,
            association_type="AssociatedWith",
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def list_upstream_associations(
            entity_arn: str,
            source_type: str,
            sagemaker_session: Session
    ):
        return AssociationHandler._list_association(
            destination_arn=entity_arn,
            source_type=source_type,
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def list_downstream_associations(
            entity_arn: str,
            destination_type: str,
            sagemaker_session: Session
    ):
        return AssociationHandler._list_association(
            source_arn=entity_arn,
            destination_type=destination_type,
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def _add_associations(
            source_arn: str,
            destination_arn: str,
            association_type: str,
            sagemaker_session: Session
    ):
        try:
            logger.info("Adding association with source_arn: %s, destination_arn: %s and association_type: %s.",
                        source_arn, destination_arn, association_type)
            association.Association.create(
                source_arn=source_arn,
                destination_arn=destination_arn,
                association_type=association_type,
                sagemaker_session=sagemaker_session
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == VALIDATION_EXCEPTION:
                logger.info("Association already exists")

    @staticmethod
    def _list_association(
            sagemaker_session: Session,
            source_arn: Optional[str] = None,
            source_type: Optional[str] = None,
            destination_arn: Optional[str] = None,
            destination_type: Optional[str] = None,
    ) -> Iterator[AssociationSummary]:
        return association.Association.list(
            source_arn=source_arn,
            source_type=source_type,
            destination_arn=destination_arn,
            destination_type=destination_type,
            sagemaker_session=sagemaker_session
        )