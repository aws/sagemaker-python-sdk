# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Contains data classes for the FeatureSchedulerConfig."""
from __future__ import absolute_import

from typing import List, Dict
import attr
from sagemaker.remote_function.spark_config import SparkConfig
from sagemaker.session import Session


@attr.s(frozen=True)
class FeatureSchedulerConfig:
    """Immutable data class containing the arguments for a FeatureSchedulerConfig.

    This class is used throughout sagemaker.feature_store.feature_scheduler.FeatureScheduler module
    for each field can be found in the FeatureScheduler class.

    Defaults are defined as literals in the FeatureScheduler schedule API's parameters for usability
    (i.e. literals in docs). Defaults, or any business logic, should not be added to this class.
    It only serves as an immutable data class.
    """

    pipeline_name: str = attr.ib()
    role: str = attr.ib()
    dependencies: str = attr.ib()
    environment_variables: Dict[str, str] = attr.ib()
    image_uri: str = attr.ib()
    include_local_workdir: bool = attr.ib()
    instance_count: int = attr.ib()
    instance_type: str = attr.ib()
    keep_alive_period_in_seconds: int = attr.ib()
    max_retry_attempts: int = attr.ib()
    max_parallelism: int = attr.ib()
    max_runtime_in_seconds: int = attr.ib()
    s3_kms_key: str = attr.ib()
    s3_root_uri: str = attr.ib()
    vpc_config: Dict[str, str] = attr.ib()
    tags: List[Dict[str, str]] = attr.ib()
    volume_kms_key: str = attr.ib()
    volume_size: int = attr.ib()
    encrypt_inter_container_traffic: bool = attr.ib()
    spark_config: SparkConfig = attr.ib()
    sagemaker_session: Session = attr.ib()

    @staticmethod
    def create(
        pipeline_name: str = None,
        role: str = None,
        dependencies: str = None,
        environment_variables: Dict[str, str] = None,
        image_uri: str = None,
        include_local_workdir: bool = False,
        instance_count: int = 1,
        instance_type: str = "ml.m5.xlarge",
        keep_alive_period_in_seconds: int = 0,
        max_retry_attempts: int = 1,
        max_parallelism: int = 1,
        max_runtime_in_seconds: int = 24 * 60 * 60,
        s3_kms_key: str = None,
        s3_root_uri: str = None,
        vpc_config: Dict[str, str] = None,
        tags: List[Dict[str, str]] = None,
        volume_kms_key: str = None,
        volume_size: int = 30,
        encrypt_inter_container_traffic: bool = None,
        spark_config: SparkConfig = None,
        sagemaker_session: Session = None,
    ) -> "FeatureSchedulerConfig":
        """Static initializer."""
        return FeatureSchedulerConfig(
            pipeline_name=pipeline_name,
            role=role,
            dependencies=dependencies,
            environment_variables=environment_variables,
            image_uri=image_uri,
            include_local_workdir=include_local_workdir,
            instance_count=instance_count,
            instance_type=instance_type,
            keep_alive_period_in_seconds=keep_alive_period_in_seconds,
            max_retry_attempts=max_retry_attempts,
            max_parallelism=max_parallelism,
            max_runtime_in_seconds=max_runtime_in_seconds,
            s3_kms_key=s3_kms_key,
            s3_root_uri=s3_root_uri,
            vpc_config=vpc_config,
            tags=tags,
            volume_kms_key=volume_kms_key,
            volume_size=volume_size,
            encrypt_inter_container_traffic=encrypt_inter_container_traffic,
            spark_config=spark_config,
            sagemaker_session=sagemaker_session,
        )
