# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Contains a static factory for creating SparkSession instances."""
from __future__ import absolute_import

import feature_store_pyspark
from pyspark.sql import SparkSession


class SparkSessionFactory:
    """Static factory to handle SparkSession instantiation."""

    @staticmethod
    def get_spark_session() -> SparkSession:
        """Instantiate a new SparkSession."""

        return (
            SparkSession.builder
            # TODO: Apply only if _not_ executing in the SageMaker Spark Container.
            .config("spark.jars", ",".join(feature_store_pyspark.classpath_jars()))
            .config(
                "spark.jars.packages",
                "org.apache.hadoop:hadoop-aws:3.2.2,org.apache.hadoop:hadoop-common:3.2.2",
            )
            .config(
                "spark.hadoop.fs.s3a.aws.credentials.provider",
                "com.amazonaws.auth.ContainerCredentialsProvider,com.amazonaws.auth.DefaultAWSCredentialsProviderChain",
            )
            .getOrCreate()
        )
