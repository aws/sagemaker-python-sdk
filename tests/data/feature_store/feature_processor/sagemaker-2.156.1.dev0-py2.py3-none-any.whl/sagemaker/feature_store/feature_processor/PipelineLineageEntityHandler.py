# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import logging

from sagemaker import Session
from sagemaker.lineage import context

logger = logging.getLogger("sagemaker")


class PipelineLineageEntityHandler:
    @staticmethod
    def create_pipeline_context(
            pipeline_name: str,
            pipeline_arn: str,
            creation_time: str,
            last_update_time: str,
            sagemaker_session: Session
    ) -> context.Context:
        return context.Context.create(
            context_name=f'sm-fs-fe-{pipeline_name}-{creation_time}-fep',
            context_type='FeatureEngineeringPipeline',
            source_uri=pipeline_arn,
            source_type=creation_time,
            properties={
                "PipelineName": pipeline_name,
                "PipelineCreationTime": creation_time,
                "LastUpdateTime": last_update_time
            },
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def load_pipeline_context(
            pipeline_name: str,
            creation_time: str,
            sagemaker_session: Session
    ) -> context.Context:
        return context.Context.load(
            context_name=f'sm-fs-fe-{pipeline_name}-{creation_time}-fep',
            sagemaker_session=sagemaker_session
        )

    @staticmethod
    def update_pipeline_context(
            pipeline_context: context.Context
    ):
        pipeline_context.save()
