# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

from sagemaker import utils
import logging
import json
import os
from urllib.parse import urlparse
from io import BytesIO
from typing import Optional, List, Union, Dict
from sagemaker.s3 import S3Uploader
from sagemaker import image_uris
from sagemaker.spark import defaults
from sagemaker.session import Session
from sagemaker.spark.processing import SparkConfigurationUtil
from sagemaker.remote_function.spark_config import SparkConfig

logger = logging.getLogger(__name__)


class FeatureProcessorSDK:
    _default_spark_version = "3.2"
    _default_python_version = "py39"
    _default_container_version = "v1"
    _feature_processor_input_name = "feature-processor-input"
    _conf_file_name = "configuration.json"

    _submit_jars_channel_name = "jars"
    _submit_py_files_channel_name = "py_files"
    _submit_files_channel_name = "data_files"

    def __init__(self, sagemaker_session: Session = None):
        self.sagemaker_session = sagemaker_session or session_with_gamma_endpoint_override()

    def generate_remote_config(
        self,
        root_s3_uri: str = None,
        submit_jars: Optional[List[str]] = None,
        submit_py_files: Optional[List[str]] = None,
        submit_files: Optional[List[str]] = None,
        configuration: Optional[Union[List[Dict], Dict]] = None,
        spark_event_logs_uri: Optional[str] = None,
    ):

        region = self.sagemaker_session.boto_region_name
        spark_config = {}

        image_uri = image_uris.retrieve(
            framework=defaults.SPARK_NAME,
            region=region,
            version=self._default_spark_version,
            instance_type=None,
            py_version=self._default_python_version,
            container_version=self._default_container_version,
        )

        logger.info("Retrieved the spark container image uri: %s", image_uri)
        s3_prefix_uri = root_s3_uri or f"s3://{self.sagemaker_session.default_bucket()}"
        if s3_prefix_uri.endswith("/"):
            s3_prefix_uri = s3_prefix_uri[:-1]
        input_random_path = (
            f"{s3_prefix_uri}/{utils.base_from_name(self._feature_processor_input_name)}"
        )

        ## Shallow check the S3 uri
        if spark_event_logs_uri:
            SparkConfigurationUtil.validate_s3_uri(spark_event_logs_uri)
            spark_config["spark_event_logs_uri"] = spark_event_logs_uri

        if configuration:
            config_file_s3_uri = self._upload_serialized_configuration(
                input_random_path, configuration
            )
            spark_config["configuraiton_file"] = config_file_s3_uri
            logger.info(
                f"Uploaded spark configuraiotn json {configuration} to {config_file_s3_uri}"
            )

        if submit_jars:
            spark_config["submit_jars"] = self._upload_submit_deps(
                submit_jars, self._submit_jars_channel_name, input_random_path
            )

        if submit_py_files:
            spark_config["submit_py_files"] = self._upload_submit_deps(
                submit_py_files, self._submit_py_files_channel_name, input_random_path
            )

        if submit_files:
            spark_config["submit_files"] = self._upload_submit_deps(
                submit_files, self._submit_files_channel_name, input_random_path
            )

        logger.info(f"Uploaded all dependencies and the spark config generated is: {spark_config}")

        return {"spark_config": SparkConfig(**spark_config), "image_uri": image_uri}

    def _upload_serialized_configuration(self, input_base_s3_uri: str, configuration: Dict):
        SparkConfigurationUtil.validate_configuration(configuration)
        serialized_configuration = BytesIO(json.dumps(configuration).encode("utf-8"))
        config_file_s3_uri = f"{input_base_s3_uri}/" f"conf/" f"{self._conf_file_name}"
        S3Uploader.upload_string_as_file_body(
            body=serialized_configuration,
            desired_s3_uri=config_file_s3_uri,
            sagemaker_session=self.sagemaker_session,
        )

        return config_file_s3_uri

    def _upload_submit_deps(
        self, submit_deps: List[str], input_channel_name: str, input_base_s3_uri: str
    ):

        spark_opt_s3_uris = []
        if not submit_deps:
            raise ValueError(
                f"submit_deps value may not be empty. {self._submit_deps_error_message}"
            )
        if not input_channel_name:
            raise ValueError("input_channel_name value may not be empty.")

        for dep_path in submit_deps:
            dep_url = urlparse(dep_path)

            if dep_url.scheme in ["s3", "s3a"]:
                spark_opt_s3_uris.append(dep_path)
            elif not dep_url.scheme or dep_url.scheme == "file":
                if not os.path.isfile(dep_path):
                    raise ValueError(
                        f"submit_deps path {dep_path} is not a valid local file. "
                        f"{self._submit_deps_error_message}"
                    )

                upload_path = {input_base_s3_uri} / {input_channel_name} / {os.path.basename()}

                S3Uploader.upload(
                    local_path=dep_path,
                    desired_s3_uri=upload_path,
                    sagemaker_session=self.sagemaker_session,
                )

                spark_opt_s3_uris.append(upload_path)

        return spark_opt_s3_uris
