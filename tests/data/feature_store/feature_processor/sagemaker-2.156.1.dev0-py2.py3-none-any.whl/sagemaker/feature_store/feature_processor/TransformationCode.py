from typing import Optional
import attr

@attr.s
class TransformationCode:

    s3_uri: str = attr.ib()
    name: Optional[str] = attr.ib(default=None)
    author: Optional[str] = attr.ib(default=None)