from pathlib import Path
import docker
import requests
import logging
import shutil
from datetime import datetime, timedelta
from typing import Dict, List, Type
import boto3
import secrets
import platform

from sagemaker.serve.inference_spec import InferenceSpec
from sagemaker.serve.serialization import default_deserialize_client, default_serialize
from sagemaker.serve.base_mode import BaseMode
from sagemaker.serve.logging_agent import pull_logs
from sagemaker.serve.check_integrity import generate_secret_key, compute_hash
from sagemaker.serve.dependency_manager import capture_dependencies, prepare_wheel
from sagemaker.remote_function.core.serialization import _MetaData

logger = logging.getLogger(__name__)

_PING_HEALTH_CHECK_INTERVAL_SEC = 5

class LocalContainerMode(BaseMode):
    def __init__(self, inference_spec: Type[InferenceSpec], model_path: str = None, env_vars: Dict[str, str] = None):
        self.inference_spec = inference_spec
        self.model_path = model_path
        self.env_vars = env_vars
        self.container = None

    def load(self, model_path: str = None):
        path = Path(model_path if model_path else self.model_path)
        if not path.exists():
            raise Exception("model_path does not exist")
        elif not path.is_dir():
            raise Exception("model_path is not a valid directory")
        model_dir = path.joinpath("model")
        return self.inference_spec.load(str(model_dir))

    def prepare(self, dependencies: str, shared_libs: List[str], model_path: str = None):
        path = Path(model_path if model_path else self.model_path)
        if not path.exists():
            path.mkdir()
        elif not path.is_dir():
            raise Exception("model_dir is not a valid directory")

        model_dir = path.joinpath("model")
        model_dir.mkdir(exist_ok=True)
        if self.inference_spec.prepare:
            self.inference_spec.prepare(str(model_dir))

        code_dir = model_dir.joinpath("code")
        code_dir.mkdir(exist_ok=True)
        shutil.copy2(Path(__file__).parent.joinpath("inference.py"), code_dir)
        whl_dir = model_dir.joinpath('whl')
        whl_dir.mkdir(exist_ok=True)
        shutil.copy("/home/garywan/workplace/Galactus/sagemaker-2.177.1.dev0-py2.py3-none-any.whl", whl_dir)
        # prepare_wheel(boto3.client('codeartifact', region_name='us-west-2'), whl_dir)
        
        capture_dependencies(dependencies=dependencies, code_dir=code_dir)

        shared_libs_dir = model_dir.joinpath("shared_libs")
        shared_libs_dir.mkdir(exist_ok=True)
        for shared_lib in shared_libs:
            shutil.copy2(Path(shared_lib), shared_libs_dir)
            
        self.secret_key = generate_secret_key()
        with open(str(code_dir.joinpath('serve.pkl')), 'rb') as f:
            buffer = f.read()
        hash_value = compute_hash(buffer=buffer, secret_key=self.secret_key)
        with open(str(code_dir.joinpath('metadata.json')), 'wb') as metadata:
            metadata.write(_MetaData(hash_value).to_json())


    def create_server(self, image: str, container_timeout_seconds: int, env_vars: Dict[str, str] = None, model_path: str = None):
        self.destroy_server()

        client = docker.from_env()
        try:
            client.images.pull(image)
        except docker.errors.NotFound as e:
            logger.warn("Could not find remote image to pull")

        self.container = client.containers.run(image, "serve",
            detach=True,
            auto_remove=True,
            network_mode="bridge",
            volumes={
                Path(model_path if model_path else self.model_path).joinpath("model"): {'bind': '/opt/ml/model', 'mode': 'rw'},
            },
            environment={
                "SAGEMAKER_SUBMIT_DIRECTORY": "/opt/ml/model/code",
                "SAGEMAKER_PROGRAM": "inference.py",
                "SAGEMAKER_SERVE_SECRET_KEY": self.secret_key,
                "LOCAL_PYTHON": platform.python_version(),
                **(env_vars if env_vars else self.env_vars)
            }
        )

        log_generator = self.container.logs(follow=True, stream=True)
        upper = container_timeout_seconds // _PING_HEALTH_CHECK_INTERVAL_SEC
        for i in range(upper):
            pull_logs(
                (x.decode('UTF-8').rstrip() for x in log_generator),
                log_generator.close,
                datetime.now() + timedelta(seconds=_PING_HEALTH_CHECK_INTERVAL_SEC),
                i == (upper - 1) 
            )
            
            healthy, status = self._ping_container()
            if healthy:
                break

        if not healthy:
            raise Exception(f"Container did not pass the ping health check. Please increase container_timeout_seconds or review your inference code. Status Code: {status}")

    def invoke_server(self, payload: object, content_type: str, accept_type: str):
        if not callable(getattr(self.inference_spec, "serialize_request", None)):
            try:
                request, content_type = default_serialize(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in default serializer. Try providing a custom serializer using @serve.serialize_request") from e
        else:
            try:
                request = self.inference_spec.serialize_request(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.serialize_request") from e

        try:
            self.container.reload()
            ip_address = self.container.attrs['NetworkSettings']['IPAddress']
            response = requests.post(
                f"http://{ip_address}:8080/invocations",
                data=request,
                headers={'Content-Type': content_type, 'Accept': accept_type}
            )
            response.raise_for_status()
        except ValueError as e:
            raise Exception("Unable to send request to the local container server") from e

        if not callable(getattr(self.inference_spec, "deserialize_response", None)):
            try:
                return default_deserialize_client(response.content, accept_type)
            except Exception as e:
                raise Exception("Encountered error in default deserializer. Try providing a custom deserializer using @serve.deserialize_response") from e
        else:
            try:
                return self.inference_spec.deserialize_response(response.content, accept_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.deserialize_response") from e

    def _ping_container(self):
        try:
            self.container.reload()
            ip_address = self.container.attrs['NetworkSettings']['IPAddress']
            if not ip_address:
                return False

            response = requests.get(f"http://{ip_address}:8080/ping")
        except requests.exceptions.ConnectionError:
            logger.debug("Server is not up yet. Waiting...")
            return (False, 503)
        
        status_code = response.status_code
        if status_code == 200:
            logger.debug(f"Container has passed the ping health check. Status Code: {status_code}")
            return (True, status_code)

        return (False, status_code)

    def destroy_server(self):
        if self.container:
            try:
                self.container.kill()
            except docker.errors.APIError as exc:
                if exc.response.status_code < 400 or exc.response.status_code > 499:
                    raise Exception("Error encountered when cleaning up local container") from exc
            self.container = None
