import dataclasses
import uuid
from typing import Any, Callable, Type, List, Dict, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
from types import MethodType

from sagemaker import Session
from sagemaker.model import Model
from sagemaker.serializers import NumpySerializer, TorchTensorSerializer
from sagemaker.deserializers import JSONDeserializer, TorchTensorDeserializer
from sagemaker.serve.function_container import Mode
from sagemaker.serve.sagemaker_endpoint_mode import SageMakerEndpointMode
from sagemaker.serve.local_container_mode import LocalContainerMode
from sagemaker.serve.pickler import save_pkl
from sagemaker.serve.serve_settings import _ServeSettings
from sagemaker.predictor import Predictor
from sagemaker.serve.inference_spec import InferenceSpec
from sagemaker.serve.predictors import LocalModePredictor
from sagemaker.serve.image_detector import auto_detect_container

import logging

logger = logging.getLogger(__name__)


class ModelServer(Enum):
    def __str__(self):
        return str(self.name)

    TORCHSERVE = 1
    MMS = 2
    TENSORFLOW_SERVING = 3
    DJL = 4
    TRITON = 5
    TGI = 6


@dataclass
class ModelBuilder:
    model_path: str = field(metadata={"help": "Define the path of model directory"})
    role_arn: Optional[str] = field(default=None, metadata={"help": "Define the role for the endpoint"})
    sagemaker_session: Optional[Session] = field(default=None, metadata={"help": "Define sagemaker session for execution"})
    name: Optional[str] = field(default='model-name-' + uuid.uuid1().hex,
                                metadata={"help": "Define the model name"})
    mode: Optional[Mode] = field(default=Mode.SAGEMAKER_ENDPOINT,
                                 metadata={"help": "Define the mode of operation"
                                                   "Model Builder supports three modes "
                                                   "1/ SageMaker Endpoint"
                                                   "2/ Local launch with container"
                                                   "3/ Local launch in process"})

    shared_libs: List[str] = field(default_factory=lambda: [],
                                   metadata={"help": "Define any shared lib you want to bring into the model "
                                                     "packaging"})
    dependencies: Optional[Dict[str, Any]] = field(default_factory=lambda: {"auto": True},
                                                   metadata={"help": "Define the dependencies of the model/container"})
    env_vars: Optional[Dict[str, str]] = field(default_factory=lambda: {},
                                               metadata={"help": "Define the environment variables"})
    log_level: Optional[int] = field(default=logging.DEBUG,
                                     metadata={"help": "Define the log level"})
    content_type: Optional[str] = field(default=None,
                                        metadata={"help": "Define the content type of the input data to the endpoint"})
    accept_type: Optional[str] = field(default=None,
                                       metadata={"help": "Define the accept type of the output data from the endpoint"})
    s3_model_data_url: Optional[str] = field(default=None,
                                             metadata={"help": "Define the s3 location "
                                                               "where you want to upload the model package"})
    instance_type: Optional[str] = field(default="ml.c5.xlarge",
                                         metadata={"help": "Define the instance_type of the endpoint"})
    schema_builder: Optional[str] = field(default=None,
                                         metadata={"help": "Defines the i/o schema of the model"})
    model: Optional[Any] = field(default=None, metadata={"help": "Model object with \"predict\" method to "
                                                         "perform inference"})
    inference_spec: InferenceSpec = field(default=None, metadata={"help": "Define the inference spec file "
                                                            "for all customizations"})
    image_uri: Optional[str] = field(default=None, metadata={"help": "Define the container image uri"})

    def build(
        self,
        mode: Type[Mode] = None,
        role_arn: str = None,
        sagemaker_session: str = None
    ) -> Type[Model]:
        self.modes = {
            str(Mode.SAGEMAKER_ENDPOINT): SageMakerEndpointMode(inference_spec=self.inference_spec)
        }
        if mode:
            self.mode = mode
        if role_arn:
            self.role_arn = role_arn
        if sagemaker_session:
            self.sagemaker_session = sagemaker_session or Session()

        if self.inference_spec:
            save_pkl(self.model_path, self.inference_spec)
        elif self.model:
            save_pkl(self.model_path, (self.model, self.schema_builder))

        if not self.image_uri:
            if not self.model:
                raise Exception("Cannot detect required image without model")
            elif not self.instance_type:
                raise Exception("Cannot detect required image without instance type")
            elif not self.image_uri:
                self.image_uri = auto_detect_container(
                    self.model, 
                    self.sagemaker_session.boto_region_name,
                    self.instance_type
                )



        serve_settings = _ServeSettings(
            image_uri=self.image_uri,
            role_arn=self.role_arn,
            s3_model_data_url=self.s3_model_data_url,
            instance_type=self.instance_type,
            env_vars=self.env_vars,
            content_type=self.content_type,
            accept_type=self.accept_type,
            sagemaker_session=self.sagemaker_session
        )

        # prepare the model
        s3_upload_path = None
        if self.mode == Mode.SAGEMAKER_ENDPOINT:            
            s3_upload_path, env_vars_sagemaker = self.modes[str(Mode.SAGEMAKER_ENDPOINT)].prepare(
                self.model_path,
                self.dependencies,
                self.shared_libs,
                serve_settings.s3_model_data_url,
                self.sagemaker_session,
                serve_settings.image_uri
            )
            self.env_vars.update(env_vars_sagemaker)
        elif self.mode == Mode.LOCAL_CONTAINER:
            # init the LocalContainerMode object
            self.modes[str(Mode.LOCAL_CONTAINER)] = LocalContainerMode(inference_spec=self.inference_spec,
                                                                        model_path=self.model_path,
                                                                        env_vars=self.env_vars)
            self.modes[str(Mode.LOCAL_CONTAINER)].load()
            self.modes[str(Mode.LOCAL_CONTAINER)].prepare(self.dependencies, self.shared_libs)
        else:
            logger.info("IN_PROCESS Not supported yet!")

        model = Model(
            image_uri=serve_settings.image_uri,
            model_data=s3_upload_path,
            role=serve_settings.role_arn,
            env=self.env_vars,
            sagemaker_session=self.sagemaker_session,
            predictor_cls=self.predictor_cls
        )

        # store the modes in the model so that we may
        # reference the configurations for local deploy() & predict()
        model.mode = self.mode
        model.modes = self.modes
        model.serve_settings = serve_settings

        # dynamically generate a method to direct model.deploy() logic based on mode
        # unique method to models created via ModelBuilder()
        model.route_to_local_deployment = MethodType(route_to_local_deployment, model)

        return model

    def predictor_cls(self, endpoint_name: str, sagemaker_session: Session) -> Predictor:
        serializer = None
        if self.content_type == "application/x-npy":
            serializer = NumpySerializer()
        elif self.content_type == "tensor/pt":
            serializer = TorchTensorSerializer()
        elif self.schema_builder:
            serializer = self.schema_builder.input_serializer
        else:
            raise Exception("Cannot serialize")

        deserializer = None
        if self.accept_type == "application/json":
            deserializer = JSONDeserializer()
        elif self.accept_type == "tensor/pt":
            deserializer = TorchTensorDeserializer()
        elif self.schema_builder:
            deserializer = self.schema_builder.output_deserializer
        else:
            raise Exception("Cannot deserialize")

        return Predictor(
            endpoint_name=endpoint_name,
            sagemaker_session=sagemaker_session,
            serializer=serializer,
            deserializer=deserializer
        )


def route_to_local_deployment(self, mode: Type[Mode]) -> Tuple[object, bool]:
    '''Mixin method applied on ModelBuilder created models. Directs the traffic to local deployment or sagemaker deployment based on mode'''
    
    mode_str = str(mode)
    if not mode_str in self.modes:
        raise ValueError(f"Model is not built for {mode_str} mode. Please re-build the model via ModelBuilder.build(mode={mode_str}).")

    if mode == Mode.SAGEMAKER_ENDPOINT:
        logger.info(f"Deploying in {mode_str} mode...")
        return None, True
    elif mode == Mode.LOCAL_CONTAINER:
        logger.info(f"Deploying in {mode_str} mode...")

        mode_obj = self.modes[mode_str]
        mode_obj.create_server(self.serve_settings.image_uri, 60)

        return LocalModePredictor(mode_obj, self.serve_settings.content_type, self.serve_settings.accept_type), False
    else:
        logger.info(f"Deploying in {mode_str} mode...")
        return None, False

