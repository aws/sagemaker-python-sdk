from pathlib import Path
from typing import List
from types import ModuleType
import argparse
import email.parser
import email.policy
import json
import inspect
import itertools
import subprocess
import sys
import tqdm
 
# non native imports. Ideally add as little as possible here
# because it will add to requirements.txt
import cloudpickle
 
pipcmd = [
    sys.executable,
    "-m",
    "pip",
    "--disable-pip-version-check"
]
def get_all_files_for_installed_packages_pip(packages: List[str]):
    proc = subprocess.Popen(pipcmd + ["show", "-f"] + packages, stdout=subprocess.PIPE)
    with proc.stdout:
        lines = []
        for line in iter(proc.stdout.readline, b''):
            if line == b'---\n':
                yield lines
                lines = []
            else:
                lines.append(line)
    yield lines
    proc.wait(timeout=10) # wait for the subprocess to exit
 
def get_all_files_for_installed_packages(packages: List[str]):
    ret = {}
    for rawmsg in get_all_files_for_installed_packages_pip(packages):
        parser = email.parser.BytesParser(policy=email.policy.default)
        msg = parser.parsebytes(b''.join(iter(rawmsg)))
        ret[msg.get("Name")] = set([
            Path(msg.get("Location")).joinpath(x) for x in msg.get("Files").split()
        ])
 
    return ret
 
def batched(iterable, n):
    "Batch data into tuples of length n. The last batch may be shorter."
    # batched('ABCDEFG', 3) --> ABC DEF G
    if n < 1:
        raise ValueError('n must be at least one')
    it = iter(iterable)
    while batch := tuple(itertools.islice(it, n)):
        yield batch
 
def get_all_installed_packages():
    proc = subprocess.run(pipcmd + ["list", "--format", "json" ], stdout=subprocess.PIPE)
    return json.loads(proc.stdout)
 
def map_package_names_to_files(package_names: List[str]):
    m = {}
    batch_size = 20
    with tqdm.tqdm(total=len(package_names), desc="Scanning for dependencies", ncols=100) as pbar:
        for package_names in batched(package_names, batch_size):
            m.update(get_all_files_for_installed_packages(list(package_names)))
            pbar.update(batch_size)
    return m
 
def get_currently_used_packages():
    all_installed_packages = get_all_installed_packages()
    package_to_file_names = map_package_names_to_files([
        x["name"] for x in all_installed_packages
    ])
 
    currently_used_files = set([
        Path(m.__file__) for m in sys.modules.values()
        if inspect.ismodule(m) and hasattr(m, "__file__") and m.__file__
    ])
 
    currently_used_packages = set()
    for file in currently_used_files:
        for package in package_to_file_names.keys():
            if file in package_to_file_names[package]:
                currently_used_packages.add(package)
 
    return currently_used_packages
 
def get_requirements_for_pkl_file(pkl_path: Path, dest: Path):
    with open(pkl_path, mode='rb') as file:
        interception = cloudpickle.load(file)
 
    currently_used_packages = get_currently_used_packages()
 
    with open(dest, "w+") as out:
        for x in get_all_installed_packages():
            name = x["name"]
            # skip only for dev
            if name == "sagemaker":
                out.write("/opt/ml/model/whl/sagemaker-2.177.1.dev0-py2.py3-none-any.whl\n")
            elif name == "boto3":
                out.write("boto3==1.26.131\n")
            elif name in currently_used_packages:
                version = x["version"]
                out.write(f"{name}\n")
 
def parse_args():
    parser = argparse.ArgumentParser(
        prog='pkl_requirements',
        description='Generates a requirements.txt for a cloudpickle file'
    )
    parser.add_argument('--pkl_path', required=True, help="path of the pkl file")
    parser.add_argument('--dest', required=True, help="path of the destination requirements.txt")
    args = parser.parse_args()
    return (Path(args.pkl_path), Path(args.dest))
 
def main():
    pkl_path, dest = parse_args()
    get_requirements_for_pkl_file(pkl_path, dest)
 
if __name__ == '__main__':
    main()
