import logging
import tempfile
from typing import Any, Dict, List
from sagemaker.serve.function_container import FunctionContainer, Mode
from sagemaker.serve.in_process_mode import InProcessMode
from sagemaker.serve.local_container_mode import LocalContainerMode
from sagemaker.serve.sagemaker_endpoint_mode import SageMakerEndpointMode
from sagemaker.serve.serve_settings import _ServeSettings
from sagemaker.serve.image_detector import auto_detect_container
from sagemaker.session import Session

logger = logging.getLogger(__name__)
function_container = FunctionContainer()

modes = {
    str(Mode.IN_PROCESS): InProcessMode(function_container),
    str(Mode.LOCAL_CONTAINER): LocalContainerMode(function_container),
    str(Mode.SAGEMAKER_ENDPOINT): SageMakerEndpointMode(function_container)
}

_INTERCEPTOR_RESPONSE = "Registered {} for serving."

def invoke(
    mode: Mode,
    model_path: str = None,
    image_uri: str = None,
    port: int = 8080,
    content_type: str = None,
    accept_type: str = None,
    role_arn: str = None,
    s3_model_data_url: str = None,
    instance_type: str = None,
    env_vars: Dict[str, str] = {},
    log_level: int = logging.DEBUG,
    sagemaker_session: Session = None,
    dependencies: Dict[str, Any] = {
        "auto": True
    },
    shared_libs: List[str] = [],
    endpoint_timeout_seconds: int = 600,
    container_timeout_seconds: int = 60,
):
    logger.info(f"Starting server in {mode} mode.")

    if str(mode) not in modes:
        raise Exception(f"Invalid mode specified in @serve.invoke: {mode}")

    if not model_path:
        model_path = tempfile.TemporaryDirectory(prefix="sagemaker.serve.").name

    if function_container.mode:
        modes[str(function_container.mode)].destroy_server()

    if not function_container.load:
        raise Exception("Cannot @serve.invoke without @serve.load")

    function_container.mode = mode
    serve_settings = _ServeSettings(
        image_uri=image_uri,
        role_arn=role_arn,
        s3_model_data_url=s3_model_data_url,
        instance_type=instance_type,
        env_vars=env_vars,
        content_type=content_type,
        accept_type=accept_type,
        sagemaker_session=sagemaker_session
    )

    def _invoke(func):
        function_container.invoke = func

        # snapshot the entry points
        function_container.serialize(model_path)

        # prepare the model
        if function_container.mode == Mode.SAGEMAKER_ENDPOINT:
            modes[str(Mode.SAGEMAKER_ENDPOINT)].prepare(
                model_path,
                dependencies,
                shared_libs,
                serve_settings.s3_model_data_url,
                sagemaker_session,
                serve_settings.image_uri
            )
        elif function_container.mode == Mode.LOCAL_CONTAINER:
            modes[str(Mode.LOCAL_CONTAINER)].prepare(model_path, dependencies, shared_libs)
        else:
            modes[str(Mode.IN_PROCESS)].prepare(model_path)

        # create server
        if function_container.mode == Mode.SAGEMAKER_ENDPOINT:
            if not serve_settings.image_uri:
                serve_settings.image_uri = auto_detect_container(modes[str(Mode.SAGEMAKER_ENDPOINT)].load(model_path),
                                                                 sagemaker_session._region_name,
                                                                 instance_type)
            if not serve_settings.role_arn:
                raise Exception("SageMaker endpoint mode requires role_arn in @serve.invoke")
            if not serve_settings.instance_type:
                logger.info('instance_type is not provided in @serve.invoke. Attempting to use DeploymentRecommendation...')
            modes[str(function_container.mode)].create_server(serve_settings.image_uri,
                                                        serve_settings.role_arn,
                                                        serve_settings.instance_type,
                                                        log_level,
                                                        serve_settings.env_vars,
                                                        endpoint_timeout_seconds)
        elif function_container.mode == Mode.LOCAL_CONTAINER:
            if not serve_settings.image_uri:
                serve_settings.image_uri = auto_detect_container(modes[str(Mode.SAGEMAKER_ENDPOINT)].load(model_path),
                                                                 sagemaker_session._region_name,
                                                                 instance_type)
            modes[str(mode)].create_server(model_path,
                                           serve_settings.image_uri,
                                           serve_settings.env_vars,
                                           container_timeout_seconds)
        elif interception.mode == Mode.IN_PROCESS:
            modes[str(mode)].create_server(model_path, port, serve_settings.env_vars)

        def _invoke_for_mode(
            model,
            payload: bytes,
        ):
            return modes[str(function_container.mode)].invoke_server(
                payload, serve_settings.content_type, serve_settings.accept_type
            )

        return _invoke_for_mode

    return _invoke


def load(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("load_fn"))
    function_container.load = func
    return func

def prepare(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("prepare_fn"))
    function_container.prepare = func
    return func

def serialize_response(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("customer response serializer"))
    function_container.serialize_response = func
    return func

def serialize_request(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("custom request serializer"))
    function_container.serialize_request = func
    return func

def deserialize_response(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("custom response deserializer"))
    function_container.deserialize_response = func
    return func

def deserialize_request(func):
    logger.debug(_INTERCEPTOR_RESPONSE.format("custom request deserializer"))
    function_container.deserialize_request = func
    return func
