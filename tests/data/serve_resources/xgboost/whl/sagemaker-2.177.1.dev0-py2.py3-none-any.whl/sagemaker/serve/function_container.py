from pathlib import Path
from enum import Enum
import cloudpickle

PKL_FILE_NAME = "serve.pkl"

class Mode(Enum):
    def __str__(self):
        return str(self.name)

    IN_PROCESS = 1
    LOCAL_CONTAINER = 2
    SAGEMAKER_ENDPOINT = 3

class FunctionContainer(object):
    def __init__(self):
        self.reset()

    def reset(self):
        self.invoke = None
        self.load = None
        self.prepare = None
        self.serialize_request = None
        self.serialize_response = None
        self.deserialize_response = None
        self.deserialize_request = None
        self.mode = None

    def serialize(self, model_path: str):
        path = Path(model_path).joinpath('model').joinpath('code')
        if not path.exists():
            path.mkdir(parents=True)
        with open(path.joinpath(PKL_FILE_NAME), mode='wb') as file:
            cloudpickle.dump(self, file)