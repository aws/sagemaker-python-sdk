import argparse
from typing import Union
from typing_extensions import Annotated

import uvicorn
import logging
import cloudpickle
from fastapi import Depends, Header, FastAPI, HTTPException, Response, Request
from sagemaker.serve.serialization import default_deserialize_server, default_serialize

logger = logging.getLogger(__name__)
app = FastAPI()

async def parse_body(request: Request):
    data: bytes = await request.body()
    return data

@app.post("/invoke")
async def invoke_handler(
    payload: bytes = Depends(parse_body),
    content_type: Annotated[Union[str, None], Header()] = None,
    accept: Annotated[Union[str, None], Header()] = None
):
    if not interception.deserialize_request:
        try:
            request = default_deserialize_server(payload, content_type)
        except Exception as e:
            raise Exception("Encountered error in default deserializer. Try providing a custom serializer using @serve.deserialize_request") from e
    else:
        try:
            request = interception.deserialize_request(payload, content_type)
        except Exception as e:
            raise Exception("Encountered error in @serve.deserialize_request") from e

    prediction = interception.invoke(model, request)

    if not interception.serialize_response:
        try:
            response, accept = default_serialize(prediction, accept)
        except Exception as e:
            raise Exception("Encountered error in default serializer. Try providing a custom serializer using @serve.serialize_response") from e
    else:
        try:
            response = interception.serialize_response(prediction, accept)
        except Exception as e:
            raise Exception("Encountered error in @serve.serialize_response") from e

    return Response(content=response, media_type=accept)

if __name__ == "__main__":
    logger.info("starting server")

    parser = argparse.ArgumentParser(prog='process_server')
    parser.add_argument('-m', '--model-path')
    parser.add_argument('-p', '--port', type=int)
    args = parser.parse_args()

    # interceptions
    with open(args.model_path + '/model/code/serve.pkl', mode='rb') as file:
        interception = cloudpickle.load(file)

    # load model
    model = interception.load(args.model_path + "/model")

    uvicorn.run(app, port=args.port)
    logger.info("stopping server")

