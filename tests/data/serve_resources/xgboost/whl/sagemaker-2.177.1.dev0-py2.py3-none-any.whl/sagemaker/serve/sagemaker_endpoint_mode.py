from pathlib import Path
import shutil
from datetime import datetime
from time import sleep
from datetime import datetime, timedelta
from sagemaker import fw_utils
from sagemaker.session import Session
from sagemaker.s3_utils import (
    determine_bucket_and_prefix,
    parse_s3_url,
    s3_path_join
)
from sagemaker.s3 import S3Uploader
import logging
import platform
from typing import Callable, Dict, List, Type
import pathlib
import os

from botocore.exceptions import ClientError
from sagemaker.serve.uploader import upload_uncompressed, upload
from sagemaker.serve.function_container import FunctionContainer
from sagemaker.serve.base_mode import BaseMode
from sagemaker.serve.check_integrity import generate_secret_key, compute_hash
from sagemaker.utils import name_from_base, base_name_from_image
from sagemaker.serve.serialization import default_deserialize_client, default_serialize
from sagemaker.serve.dependency_manager import capture_dependencies, prepare_wheel
from sagemaker.serve.inference_spec import InferenceSpec

from sagemaker.remote_function.core.serialization import _MetaData

logger = logging.getLogger(__name__)


class SageMakerEndpointMode(BaseMode):
    def __init__(self, inference_spec: Type[InferenceSpec]):
        self.inference_spec = inference_spec
        self.sagemaker_session = None
        self.s3_upload_path = None
        self.model_name = None
        self.ep_config_name = None
        self.ep_name = None


    def load(self, model_path: str):
        path = Path(model_path)
        if not path.exists():
            raise Exception("model_path does not exist")
        elif not path.is_dir():
            raise Exception("model_path is not a valid directory")

        model_dir = path.joinpath("model")
        return self.inference_spec.model_fn(str(model_dir))


    def prepare(
        self,
        model_path: str,
        dependencies: str,
        shared_libs: List[str],
        s3_model_data_url: str = None,
        sagemaker_session: Session = None,
        image: str = None
    ):

        model_path = Path(model_path)
        if not model_path.exists():
            model_path.mkdir()
        elif not model_path.is_dir():
            raise Exception("model_dir is not a valid directory")
        
        try:
            self.sagemaker_session = sagemaker_session or Session()
        except Exception as e:
            raise Exception(
                "Failed to setup default SageMaker session. Please allow a default " +
                "session to be created or supply `sagemaker_session` into @serve.invoke."
            ) from e

        
        if self.inference_spec:
            self.inference_spec.prepare(str(model_path))
        
        # only for pysdk dev environment
        whl_path = model_path.joinpath("whl")
        whl_path.mkdir(exist_ok=True)
        # !pip3 wheel . -w /tmp/whl --no-deps
        shutil.copy("src/sagemaker/serve/sagemaker-2.177.1.dev0-py2.py3-none-any.whl", whl_path)

        code_dir = model_path.joinpath("code")
        code_dir.mkdir(exist_ok=True)
        shutil.copy2(Path(__file__).parent.joinpath("inference.py"), code_dir)
        whl_dir = model_path.joinpath('whl')
        whl_dir.mkdir(exist_ok=True)
        # prepare_wheel(self.sagemaker_session.boto_session.client('codeartifact', region_name='us-west-2'), whl_dir)

        shared_libs_dir = model_path.joinpath("shared_libs")
        shared_libs_dir.mkdir(exist_ok=True)
        for shared_lib in shared_libs:
            shutil.copy2(Path(shared_lib), shared_libs_dir)

        capture_dependencies(dependencies=dependencies, code_dir=code_dir)

        if s3_model_data_url:
            bucket, key_prefix = parse_s3_url(url=s3_model_data_url)
        else:
            bucket, key_prefix = None, None

        code_key_prefix = fw_utils.model_code_key_prefix(key_prefix, None, image)

        bucket, code_key_prefix = determine_bucket_and_prefix(
            bucket=bucket, key_prefix=code_key_prefix, sagemaker_session=sagemaker_session
        )

        self.secret_key = generate_secret_key()
        with open(str(code_dir.joinpath('serve.pkl')), 'rb') as f:
            buffer = f.read()
        hash_value = compute_hash(buffer=buffer, secret_key=self.secret_key)
        with open(str(code_dir.joinpath('metadata.json')), 'wb') as metadata:
            metadata.write(_MetaData(hash_value).to_json())
        logger.debug(f'Uploading the model resources to bucket={bucket}, key_prefix={code_key_prefix}.')
        self.s3_upload_path = upload(self.sagemaker_session, model_path, bucket, code_key_prefix)
        logger.debug(f'Model resources uploaded to: {self.s3_upload_path}')
        
        env_vars = {
                    "SAGEMAKER_SUBMIT_DIRECTORY": "/opt/ml/model/code",
                    "SAGEMAKER_PROGRAM": "inference.py",
                    "SAGEMAKER_REGION": self.sagemaker_session.boto_region_name,
                    "SAGEMAKER_CONTAINER_LOG_LEVEL": '10',
                    "SAGEMAKER_SERVE_SECRET_KEY": self.secret_key,
                    "LOCAL_PYTHON": platform.python_version(),
                }
        return self.s3_upload_path, env_vars
        
        

    def create_server(self, image: str, role_arn: str, instance_type: str, log_level: int,
                      env_vars: Dict[str, str], endpoint_timeout_seconds: int):
        container_defs = [
            {
                "Environment": {
                    "SAGEMAKER_SUBMIT_DIRECTORY": "/opt/ml/model/code",
                    "SAGEMAKER_PROGRAM": "inference.py",
                    "SAGEMAKER_REGION": self.sagemaker_session.boto_region_name,
                    "SAGEMAKER_CONTAINER_LOG_LEVEL": str(log_level),
                    "SAGEMAKER_SERVE_SECRET_KEY": self.secret_key,
                    "LOCAL_PYTHON": platform.python_version(),
                    **env_vars
                },
                "Image": image,
                "ModelDataUrl": self.s3_upload_path
                # "ModelDataSource":{
                #     "S3DataSource":{
                #         "S3Uri": self.s3_upload_path,
                #         "S3DataType": "S3Prefix",
                #         "CompressionType": "None",
                #     }
                # }
            }
        ]
        logger.debug("Creating SageMaker Model.")

        self.model_name = self.sagemaker_session.create_model(
            name=name_from_base(base_name_from_image(image)),
            role=role_arn,
            container_defs=container_defs
        )
        logger.debug("created model")
        sleep(5)
        describe_response = self.sagemaker_session.describe_model(name=self.model_name)
        if not instance_type:
            try:
                instance_type = describe_response.get('DeploymentRecommendation')\
                    .get('RealTimeInferenceRecommendations')[0].get('InstanceType')
                logger.debug(f"Deploying to instance type {instance_type}")
            except Exception as e:
                raise Exception("DeploymentRecommendation failed. Please provide \"instance_type\" in @serve.invoke")

        logger.debug("Creating Endpoint Configuration.")

        self.ep_config_name = self.sagemaker_session.create_endpoint_config(
            name=name_from_base(base_name_from_image(image)),
            model_name=self.model_name,
            instance_type=instance_type,
            initial_instance_count=1
        )

        endpoint_name = name_from_base(base_name_from_image(image))

        logger.debug(f'Creating Endpoint {endpoint_name}.')

        self.ep_name = self.sagemaker_session.create_endpoint(
            endpoint_name=endpoint_name,
            config_name=self.ep_config_name,
            wait=False
        )

        client = self.sagemaker_session.boto_session.client("logs")
        paginator = client.get_paginator('filter_log_events')
        config={ "MaxItems": 100, "PageSize": 10 }
        endpoint_timeout = datetime.now() + timedelta(seconds=endpoint_timeout_seconds)
        stop_log = False
        endpoint_status = None
        while not stop_log:
            if endpoint_timeout < datetime.now():
                raise Exception("Endpoint not In Service")

            sleep(10)

            try:
                desc = self.sagemaker_session.sagemaker_client.describe_endpoint(EndpointName=self.ep_name)
                new_endpoint_status = desc["EndpointStatus"]
                if new_endpoint_status == "Failed" and endpoint_status != "Creating":
                    logger.debug("Endpoint failed. Waiting for logs")
                    sleep(120)

                endpoint_status = new_endpoint_status
                if endpoint_status != "Creating":
                    stop_log = True
                    continue
            except ClientError as e:
                if e.response["Error"]["Code"] == "ValidationException":
                    logger.debug("Waiting for endpoint to become visible")
                    continue
                else:
                    raise e

            try:
                pages = paginator.paginate(
                    logGroupName=f"/aws/sagemaker/Endpoints/{endpoint_name}",
                    logStreamNamePrefix="AllTraffic/",
                    PaginationConfig=config
                )

                for page in pages:
                    if "nextToken" in page:
                        config["StartingToken"] = page["nextToken"]
                        for event in page["events"]:
                            logger.info(event['message'])
                    else:
                        logger.debug("No log events available")
            except ClientError as e:
                if e.response["Error"]["Code"] == "ResourceNotFoundException":
                    logger.debug("Waiting for endpoint log group to appear")
                    sleep(110)
                else:
                    raise e

        if endpoint_status != "InService":
            raise Exception("Endpoint not in service")

        logger.debug(f'\nSuccessfully deployed to SageMaker Endpoint {self.ep_name}')

    def invoke_server(self, payload: object, content_type: str, accept_type: str):
        if not self.function_container.serialize_request:
            try:
                request, content_type = default_serialize(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in default serializer. Try providing a custom serializer using @serve.serialize_request") from e
        else:
            try:
                request = self.function_container.serialize_request(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.serialize_request") from e
        try:
            args = {
                "EndpointName": self.ep_name,
                "Body": request,
            }

            if content_type:
                args["ContentType"] = content_type

            if accept_type:
                args["Accept"] = accept_type

            response = self.sagemaker_session.sagemaker_runtime_client.invoke_endpoint(**args)
        except ValueError as e:
            raise Exception("Unable to send request to the sagemaker endpoint") from e

        if not self.function_container.deserialize_response:
            try:
                return default_deserialize_client(response.get('Body').read(), accept_type)
            except Exception as e:
                raise Exception("Encountered error in default deserializer. Try providing a custom deserializer using @serve.deserialize_response") from e
        else:
            try:
                return self.function_container.deserialize_response(response.get('Body').read(), accept_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.deserialize_response") from e

    def destroy_server(self):
        if self.ep_name:
            self.sagemaker_session.delete_endpoint(endpoint_name=self.ep_name)
            self.ep_name = None
        if self.ep_config_name:
            self.sagemaker_session.delete_endpoint_config(endpoint_config_name=self.ep_config_name)
            self.ep_config_name = None
        if self.model_name:
            self.sagemaker_session.delete_model(model_name=self.model_name)
            self.model_name= None
