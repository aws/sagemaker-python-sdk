import numpy as np

from sagemaker.deserializers import (
    BaseDeserializer,
    BytesDeserializer,
    NumpyDeserializer,
    JSONDeserializer,
    StringDeserializer,
    TorchTensorDeserializer
)
from sagemaker.serializers import (
    DataSerializer,
    NumpySerializer,
    JSONSerializer,
    TorchTensorSerializer
)

class DeserializerWrapper(BaseDeserializer):
    def __init__(self, deserializer, content_type):
        self._deserializer = deserializer
        self._content_type = content_type

    def deserialize(self, stream, content_type):
        return self._deserializer.deserialize(
            stream,
            # We need to overwrite the accept type because model
            # servers like XGBOOST always returns "text/html"
            self._content_type
        )

    @property
    def ACCEPT(self):
        return self._content_type

class SchemaBuilder(object):
    def __init__(self, input_obj, output_obj):
        self.input_serializer = self._get_serializer(input_obj)
        self._input_deserializer = self._get_inverse(self.input_serializer)
        self._output_deserializer = self._get_deserializer(output_obj)
        self.output_serializer = self._get_inverse(self._output_deserializer)

        self.input_deserializer = DeserializerWrapper(
            self._get_inverse(self.input_serializer),
            self.input_serializer.CONTENT_TYPE
        )
        self.output_deserializer = DeserializerWrapper(
            self._output_deserializer,
            self.output_serializer.CONTENT_TYPE
        )

    def _get_serializer(self, obj):
        if isinstance(obj, np.ndarray):
            return NumpySerializer()
        elif isinstance(obj, bytes):
            return DataSerializer()
        elif _is_torch_tensor(obj):
            return TorchTensorSerializer()
        else:
            try:
                JSONSerializer().serialize(obj)
                return JSONSerializer()
            except Exception as e:
                return DataSerializer() 

    def _get_deserializer(self, obj):
        if isinstance(obj, np.ndarray):
            return NumpyDeserializer()
        elif isinstance(obj, bytes):
            return BytesDeserializer()
        elif _is_torch_tensor(obj):
            return TorchTensorDeserializer()
        else:
            try:
                JSONSerializer().serialize(obj)
                return JSONDeserializer()
            except Exception as e:
                return obj


    def _get_inverse(self, obj):
        if isinstance(obj, NumpySerializer):
            return NumpyDeserializer()
        elif isinstance(obj, NumpyDeserializer):
            return NumpySerializer()
        elif isinstance(obj, JSONDeserializer):
            return JSONSerializer()
        elif isinstance(obj, JSONSerializer):
            return JSONDeserializer()
        elif isinstance(obj, TorchTensorSerializer):
            return TorchTensorDeserializer()
        elif isinstance(obj, TorchTensorDeserializer):
            return TorchTensorSerializer()
        elif isinstance(obj, DataSerializer):
            return BytesDeserializer()
        elif isinstance(obj, BytesDeserializer):
            return DataSerializer()
        else:
            raise Exception("Unable to serialize")


def _is_torch_tensor(data: object):
    try:
        from torch import Tensor
        return isinstance(data, Tensor)
    except Exception:
        return False