import abc

class BaseMode(abc.ABC):
    @abc.abstractclassmethod
    def load(self, model_path: str):
        pass

    @abc.abstractclassmethod
    def prepare(self, model_path: str):
        pass

    @abc.abstractclassmethod
    def create_server(self):
        pass

    @abc.abstractclassmethod
    def invoke_server(self, payload: object, content_type: str, accept_type: str):
        pass

    @abc.abstractclassmethod
    def destroy_server(self):
        pass