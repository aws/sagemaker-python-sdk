# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""SageMaker @serve dependency managing module. This must be kept independent of SageMaker PySDK"""

from __future__ import absolute_import

from pathlib import Path
import logging
import shutil
import os
import subprocess
import sys
import time
import random
import uuid


_SUPPORTED_SUFFIXES = [".txt"]
# TODO : Move PKL_FILE_NAME to common location
PKL_FILE_NAME = "serve.pkl"

logger = logging.getLogger(__name__)

def capture_dependencies(dependencies: str, code_dir: Path):
    path = code_dir.joinpath("requirements.txt")
    if "auto" in dependencies and dependencies["auto"]:
        #_capture_from_local_environment(code_dir)
        subprocess.run([
            sys.executable, Path(__file__).parent.joinpath("pickle_dependencies.py"),
            "--pkl_path", code_dir.joinpath(PKL_FILE_NAME), "--dest", path
        ], env = {
            "SETUPTOOLS_USE_DISTUTILS": "stdlib"
        }, check=True)

    if "requirements" in dependencies:
        _capture_from_customer_provided_requirements(dependencies["requirements"], path)
    
    if "custom" in dependencies:
        with open(path, "a+") as f:
            for package in dependencies["custom"]:
                f.write(f"{package}\n")

def _capture_from_customer_provided_requirements(requirements_file: str, output_path: Path):
    input_path = Path(requirements_file)
    if not input_path.is_file() or not _is_valid_requirement_file(input_path):
        raise Exception(f'Path: {requirements_file} to requirements.txt doesn\'t exist')
    logger.debug(f'Packaging provided requirements.txt from {requirements_file}')
    with open(output_path, "a+") as f:
        shutil.copyfileobj(open(input_path, "r"), f)
        
        
def _capture_from_local_environment(code_dir: str):
    requirement_output = os.path.join(code_dir, "requirements.txt")
    log_dir = Path(code_dir).resolve().parent.parent.joinpath("logs")
    log_dir.mkdir(exist_ok=True)
    log_output = os.path.join(str(log_dir), _unique_name_from_base("output.log"))
    command = f"pigar gen -f {requirement_output} {os.getcwd()}"
    logger.info("Resolving dependencies...")
    
    start_time = time.time()
    timeout = 20 # timeout for 20 seconds
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
    
    with open(log_output, 'w') as log_file:
        while True:
            if time.time() - start_time >= timeout:
                logger.error("Resolve dependencies timed out. Please provide a path to your requirements.txt")
                break
            elif process.poll() is not None:
                logger.info("Successfully resolved dependencies. ")
                break
            elif process.stdin and process.stdin.writable():
                process.communicate(input=b'N\n')
            else:
                output = process.stdout.readline().decode().strip()
                log_file.write(output + '\n')
    
        remaining_output, _ = process.communicate()
        log_file.write("\n" + remaining_output.decode().strip() + "\n")
    
    logger.info(f"Output log saved to {log_output}")
    process.terminate()
        
    # only for development, remove sagemaker because we are installing from wheel
    with open(requirement_output, 'r') as req:
        dependencies = req.readlines()
        
    # We can do a dependency check here and fail early if we know it's not compatible
    filtered_dependencies = [dependency for dependency in dependencies if not dependency.startswith('sagemaker')]
    
    with open(requirement_output, 'w') as req:
        req.writelines(filtered_dependencies)
        

def _unique_name_from_base(base: str, max_length=63):
    """Placeholder Docstring"""
    random.seed(int(uuid.uuid4()))  # using uuid to randomize, otherwise system timestamp is used.
    unique = "%04x" % random.randrange(16**4)  # 4-digit hex
    ts = str(int(time.time()))
    available_length = max_length - 2 - len(ts) - len(unique)
    trimmed = base[:available_length]
    return f"{trimmed}-{ts}-{unique}"


def _is_valid_requirement_file(path):
    # In the future, we can also check the if the content of customer provided file has valid format
    for suffix in _SUPPORTED_SUFFIXES:
        if path.name.endswith(suffix):
            return True
    return False


# only required for dev testing
def prepare_wheel(code_artifact_client, whl_dir: str):
    # pull from code artifact
    input_dict = {
        "domain": "galactus-preview-builds",
        "domainOwner": "661407751302",
        "repository": "beta-1",
        "format": "pypi",
        "package": "sagemaker",
        "packageVersion": "2.177.1.dev0",
        "asset": "sagemaker-2.177.1.dev0-py2.py3-none-any.whl"
    }

    response = code_artifact_client.get_package_version_asset(**input_dict)
    whl_binary = response.get('asset').read()
    
    with open(f'{whl_dir}/sagemaker-2.177.1.dev0-py2.py3-none-any.whl', 'wb') as binary_file:
        binary_file.write(whl_binary)