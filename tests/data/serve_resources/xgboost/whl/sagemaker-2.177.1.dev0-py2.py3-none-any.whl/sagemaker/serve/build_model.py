from argparse import ArgumentParser, Namespace

import sagemaker
from model_builder import ModelBuilder
from sagemaker.model import Model
from sagemaker import Session
from inference_spec import InferenceSpec

import uuid
import boto3
import os
import importlib.util
import inspect

parser = ArgumentParser(description='build model package and '
                                    'create model reference in sagemaker')

parser.add_argument('--model-name',
                    help='define the inference spec file',
                    default='model-name-' + uuid.uuid1().hex, )

parser.add_argument('--inference-spec',
                    help='define the inference spec file',
                    nargs='?')

# TODO: we will derive the following parameters,
#  Adding it to command line parser for completeness.
parser.add_argument('--model-path',
                    help='define the path of model directory',
                    nargs='?')

parser.add_argument('--image-uri',
                    help='define the container image uri',
                    nargs='?')

parser.add_argument('--role-arn',
                    help='define the role for the endpoint',
                    nargs='?')

parser.add_argument('-r', '--region',
                    help='define the AWS region',
                    nargs='?')

args: Namespace = parser.parse_args()

session = Session(boto_session=boto3.session.Session(region_name="us-west-2"))

print(args.inference_spec + " " + args.model_path + " " + args.model_path + " " +
      args.image_uri + " " + args.role_arn)

inference_spec_with_base_path = os.path.join(args.model_path, args.inference_spec)

# Load the module
spec = importlib.util.spec_from_file_location("__temp_module__", inference_spec_with_base_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class_name = None
for name, obj in inspect.getmembers(module):
    if inspect.isclass(obj) and issubclass(obj, sagemaker.serve.inference_spec.InferenceSpec) \
            and obj != sagemaker.serve.inference_spec.InferenceSpec:
        class_name = name
        break

print("Class name of the inference spec file: " + class_name)

# Get the class from the module
try:
    inference_spec_reference: InferenceSpec = getattr(module, class_name)
except AttributeError:
    raise AttributeError(f"Class InferenceSpec not found in the file '{args.inference_spec}'.")

builder: ModelBuilder = ModelBuilder(inference_spec=inference_spec_reference(),
                                     name=args.model_name,
                                     model_path=args.model_path,
                                     image_uri=args.image_uri,
                                     role_arn=args.role_arn,
                                     sagemaker_session=session)
model: Model = builder.build()

print(model)

