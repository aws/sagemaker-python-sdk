from typing import Type
from sagemaker.serve.local_container_mode import LocalContainerMode

class LocalModePredictor():
    '''Lightweight predictor for local deployment in IN_PROCESS and LOCAL_CONTAINER modes'''

    # TODO: change mode_obj to union of IN_PROCESS and LOCAL_CONTAINER objs
    def __init__(self, mode_obj: Type[LocalContainerMode], content_type: str, accept_type: str):
        self._mode_obj = mode_obj
        self.content_type = content_type
        self.accept_type = accept_type

    def predict(self, data: object, content_type: str = None, accept_type: str = None):
        return self._mode_obj.invoke_server(data, 
                                            content_type if content_type else self.content_type,
                                            accept_type if accept_type else self.accept_type)
