import logging
import sys
from threading import Thread
import queue
import time
from datetime import datetime
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

def _get_logs(generator, logs, until):
    now = datetime.now()
    try:
        for next_entry in generator:
            logs.put(next_entry, block=True, timeout=(until - now).total_seconds())
            
            now = datetime.now()
            if until < now:
                break
        logger.debug("Container logging done. All container logs processed.")
    except StopIteration as e:
        logger.debug("Container logging stopped. All container logs processed.")
    except Exception as e:
        logger.exception("Container Logging Stopped. Container failed.", e)

def pull_logs(generator, stop, until, final_pull):
    now = datetime.now() 
    if until < now:
        return

    logs = queue.Queue(maxsize=10)
    log_puller = Thread(
        target=_get_logs,
        args=(generator, logs, until,)
    )
    log_puller.start()

    while True: 
        try:
            top = logs.get(block=True, timeout=(until - now).total_seconds())
            logger.debug(top)
        except queue.Empty as e:
            now = datetime.now() 
            if until < now:
                if not final_pull:
                    return

                stop()
                # allow logging thread some time to cleanup
                log_puller.join(timeout=5)
                if log_puller.is_alive():
                    raise Exception("Logging thread not terminating")
                return

