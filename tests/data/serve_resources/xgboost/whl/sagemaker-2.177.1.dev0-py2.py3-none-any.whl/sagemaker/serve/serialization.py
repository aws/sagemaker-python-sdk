from sagemaker.deserializers import BytesDeserializer, NumpyDeserializer, JSONDeserializer, StringDeserializer, TorchTensorDeserializer
from sagemaker.serializers import DataSerializer, NumpySerializer, JSONSerializer, TorchTensorSerializer
import io
import numpy as np
import json
from typing import Tuple

npser = NumpySerializer()
npdeser = NumpyDeserializer()
jsonser = JSONSerializer()
jsondeser = JSONDeserializer()
bytesdeser = BytesDeserializer()
dataser = DataSerializer()
strdeser = StringDeserializer()
torchser = TorchTensorSerializer()
torchdeser = TorchTensorDeserializer()

def default_serialize(obj: object, content_type: str) -> Tuple[bytes, str]:
    if not content_type:
        return _default_serialize_autodetect(obj)
    elif content_type == "application/octet-stream":
        return (obj, "application/octet-stream")
    elif content_type == "text/plain":
        return (obj.encode("utf-8"), "text/plain")
    elif content_type == "application/json":
        return (jsonser.serialize(obj), "application/json")
    elif content_type == "application/x-npy":
        return (npser.serialize(obj), "application/x-npy")
    elif _is_torch_tensor(obj):
        return (torchser.serialize(obj), "tensor/pt")

def _default_serialize_autodetect(obj: object) -> Tuple[bytes, str]:
    try:
        if isinstance(obj, np.ndarray):
            return (npser.serialize(obj), "application/x-npy")
        else:
            if isinstance(obj, str):
                return (obj.encode("utf-8"), "text/plain")
            else:
                try:
                    return (jsonser.serialize(obj), "application/json")
                except Exception as e:
                    return (dataser.serialize(obj), "application/data")
    except Exception as e:
        return (obj, "application/octet-stream")


def default_deserialize_server(payload: bytes, content_type: str) -> object:
    if not content_type or content_type == "application/octet-stream":
        return bytesdeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "application/data":
        try:
            return strdeser.deserialize(io.BytesIO(payload), content_type)
        except Exception as e:
            return bytesdeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "text/plain":
        return payload.decode("utf-8")
    elif content_type == "application/json":
        # do not attempt to deserialize application/json. The inference toolkit
        # model server automatically does that
        return payload
    elif content_type == "application/x-npy":
        return npdeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "tensor/pt":
        return torchdeser.deserialize(io.BytesIO(payload))

def default_deserialize_client(payload: bytes, content_type: str) -> object:
    if not content_type or content_type == "application/octet-stream":
        return bytesdeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "application/data":
        try:
            return strdeser.deserialize(io.BytesIO(payload), content_type)
        except Exception as e:
            return bytesdeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "text/plain":
        return payload.decode("utf-8")
    elif content_type == "application/json":
        return jsondeser.deserialize(io.BytesIO(payload), content_type)
    elif content_type == "application/x-npy":
        return npdeser.deserialize(io.BytesIO(payload), content_type)


def _is_torch_tensor(obj) -> bool:
    try:
        from torch import Tensor
        return isinstance(obj, Tensor)
    except Exception:
        return False