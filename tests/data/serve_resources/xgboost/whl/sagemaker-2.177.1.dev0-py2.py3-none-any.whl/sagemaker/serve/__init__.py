import logging
from sagemaker.serve.interceptors import (
    invoke, load, serialize_response,
    deserialize_response, serialize_request,
    deserialize_request, prepare
)

from sagemaker.serve.model_builder import ModelBuilder
from sagemaker.serve.inference_spec import InferenceSpec
from sagemaker.serve.function_container import Mode
from sagemaker.serve.schema_builder import SchemaBuilder

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
streamHandler = logging.StreamHandler()
streamHandler.setFormatter(logging.Formatter("@serve: %(levelname)s:     %(message)s"))
logger.addHandler(streamHandler)
