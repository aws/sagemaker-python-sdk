from sagemaker import image_uris
import platform
import logging

logger = logging.getLogger(__name__)

_VERSION_DETECTION_ERROR = "Framework version was unable to be found for the provided {} model. The latest supported framework version will be used."
_CASTING_WARNING = "Could not find the framework version {} in supported framework versions for the DLC. Mapping to the nearest latest minor version. The available compatible versions are as follows {}"

def auto_detect_container(model, region, instance_type):
    '''auto detect the container off of model and instance type'''

    logger.info("Autodetecting image since image_uri was not provided in @serve.invoke")

    if not instance_type:
        raise Exception("Instance type is not specified. Unable to detect if the container needs to be GPU or CPU.")

    logger.warn("Auto detection is only supported for single models DLCs with a framework backend.")

    model_base = model.__class__.__base__
    py_tuple = platform.python_version_tuple()

    fw, fw_version = _detect_framework_and_version(str(model_base))
    logger.info(f"Autodetected framework is {fw}")
    logger.info(f"Autodetected framework version is {fw_version}")

    dlc = image_uris.retrieve(
        framework=fw,
        region=region,
        version=fw_version if not fw_version else _cast_to_compatible_version(fw, fw_version),
        image_scope='inference',
        py_version=f'py{py_tuple[0]}{py_tuple[1]}',
        instance_type=instance_type
    )

    logger.info(f'Auto detected {dlc}. Proceeding with the the deployment.')

    return dlc


def _cast_to_compatible_version(framework, fw_version):
    config = image_uris._config_for_framework_and_scope(framework, 'inference', None)    
    available_versions = list(config["versions"].keys())
    earliest_upcast_version = None
    latest_downcast_version = None

    split_vs = fw_version.split(".")

    for version in available_versions:
        up_cast, down_cast, found = _find_compatible_vs(split_vs, version)
        if found:
            logger.info(f'Framework version {version} found in available versions')
            return found
        if up_cast:
            if not earliest_upcast_version or _later_version(earliest_upcast_version, up_cast):
                earliest_upcast_version = up_cast
        if down_cast:
            if not latest_downcast_version or not _later_version(latest_downcast_version, down_cast):
                latest_downcast_version = down_cast
    
    if earliest_upcast_version:
        logger.warn(_CASTING_WARNING.format(fw_version, available_versions))
        return earliest_upcast_version
    
    if latest_downcast_version:
        logger.warn(_CASTING_WARNING.format(fw_version, available_versions))
        return latest_downcast_version

    raise Exception(f'Auto detection could not find a compatible DLC version mapped to {fw_version}. The available compatible versions are as follows {available_versions}.')


def _later_version(current, found):
    split_current = current.split(".")
    split_minor_current = split_current[1].split("-")
    split_found = found.split(".")
    split_minor_found = split_found[1].split("-")

    if split_current[0] == split_found[0]:
        mini_current = split_current[2] if len(split_minor_current) == 1 else split_minor_current[1]
        mini_found =  split_found[2] if len(split_minor_found) == 1 else split_minor_found[1]
        return mini_current > mini_found

    return split_current[0] > split_found[0]


def _find_compatible_vs(split_vs, supported_vs):
    earliest_upcast_version = None
    latest_downcast_version = None
    found_version = None

    split_supported_vs = supported_vs.split(".")

    # if same major version
    if split_vs[0] == split_supported_vs[0]:
        # if no minor or mini version
        if len(split_supported_vs) == 1:
            if len(split_vs) == 1:
                return (None, None, supported_vs)
            else:
                return (None, None, None)
        
        # the minor and mini could be joined as such 1.2-1
        split_supported_minor = split_supported_vs[1].split("-")
        
        # if same minor version
        if split_vs[1] == split_supported_minor[0]:
            mini = split_supported_vs[2] if len(split_supported_minor) == 1 else split_supported_minor[1]
            if split_vs[2] == mini:
                found_version = supported_vs
            elif split_vs[2] < mini:
                earliest_upcast_version = supported_vs
            else:
                latest_downcast_version = supported_vs
        elif split_vs[1] < split_supported_minor[0]:
            earliest_upcast_version = supported_vs
        
    return (earliest_upcast_version, latest_downcast_version, found_version)


def _detect_framework_and_version(model_base):
    '''Parse fw based off the base model object and get version if possible'''
    fw = ""
    vs = ""
    if "torch" in model_base:
        fw = "pytorch"
        try:
            import torch
            vs = torch.__version__
        except Exception as e:
            logger.warn(_VERSION_DETECTION_ERROR.format(fw))
    elif "tensorflow" in model_base:
        fw = "tensorflow"
        try:
            import tensorflow
            vs = tensorflow.__version__
        except Exception as e:
           logger.warn(_VERSION_DETECTION_ERROR.format(fw)) 
    elif "xgb" in model_base:
        fw = "xgboost"
        try:
            import xgboost
            vs = xgboost.__version__
        except Exception as e:
            logger.warn(_VERSION_DETECTION_ERROR.format(fw))
    return (fw, vs)
