import abc
from typing import Tuple

from sagemaker.serve.serialization import default_deserialize_server, default_serialize



class InferenceSpec(abc.ABC):
    @abc.abstractmethod
    def load(self, model_dir: str):
        pass

    @abc.abstractmethod
    def invoke(self, input_object: object, model: object):
        pass

    def prepare(self, *args, **kwargs):
        pass

    def deserialize_request(self, payload: bytes, content_type: str) -> object:
        try:
            return default_deserialize_server(payload, content_type)
        except Exception as e:
            raise Exception("Encountered error in default deserializer. Please provide a custom deserializer.") from e

    def serialize_response(self, predictions, accept_type) -> Tuple[bytes, str]:
        try:
            return default_serialize(predictions, accept_type)
        except Exception as e:
            raise Exception("Encountered error in default serializer. Please provide a custom serializer.") from e
