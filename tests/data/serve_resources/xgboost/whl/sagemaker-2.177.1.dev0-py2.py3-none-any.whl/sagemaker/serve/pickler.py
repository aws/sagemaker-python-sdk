from typing import Any
from pathlib import Path
import cloudpickle

PKL_FILE_NAME = "serve.pkl"

def save_pkl(model_path: str, obj: Any):
    path = Path(model_path).joinpath('code')
    if not path.exists():
        path.mkdir(parents=True)
    with open(path.joinpath(PKL_FILE_NAME), mode='wb') as file:
        cloudpickle.dump(obj, file)
