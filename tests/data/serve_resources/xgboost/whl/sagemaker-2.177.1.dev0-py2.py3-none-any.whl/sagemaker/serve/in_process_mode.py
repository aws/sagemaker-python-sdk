import os
from pathlib import Path
from time import sleep
import subprocess
import requests
import sys
import shutil
import logging
from typing import Dict

import sagemaker.serve.in_process_server as server
from sagemaker.serve.function_container import FunctionContainer
from sagemaker.serve.serialization import default_deserialize_client, default_serialize
from sagemaker.serve.base_mode import BaseMode

logger = logging.getLogger(__name__)

class InProcessMode(BaseMode):
    def __init__(self, interception: FunctionContainer):
        self.interception = interception
        self.proc = None
        self.port = None

    def load(self, model_path: str):
        path = Path(self.interception.model_path)
        if not path.exists():
            raise Exception("model_path does not exist")
        elif not path.is_dir():
            raise Exception("model_path is not a valid directory")

        model_dir = path.joinpath("model")
        return self.interception.load(str(model_dir))

    def prepare(self, model_path: str):
        path = Path(model_path)
        if not path.exists():
            path.mkdir()
        elif not path.is_dir():
            raise Exception("model_path is not a valid directory")

        model_dir = path.joinpath("model")
        model_dir.mkdir(exist_ok=True)
        if self.interception.prepare:
            self.interception.prepare(str(model_dir))
        codedir = model_dir.joinpath("code")
        codedir.mkdir(exist_ok=True)
        shutil.copy2(Path(__file__).parent.joinpath("inference.py"), codedir)

    def create_server(self, model_path: str, port: int, env_vars: Dict[str, str]):
        if self.proc:
            self.proc.terminate()
            self.proc.wait()
            self.proc = None

        self.proc = subprocess.Popen([
            sys.executable,
            server.__file__,
            "-m", model_path,
            "-p", str(port)
        ], env=env_vars, shell=False)
        self.port = port
        sleep(5)

    def invoke_server(self, payload: object, content_type: str, accept_type: str):
        if not self.interception.serialize_request:
            try:
                request, content_type = default_serialize(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in default serializer. Try providing a custom serializer using @serve.serialize_request") from e
        else:
            try:
                request = self.interception.serialize_request(payload, content_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.serialize_request") from e

        try:
            response = requests.post(
                f"http://127.0.0.1:{self.port}/invoke",
                data=request,
                headers={'Content-Type': content_type, 'Accept': accept_type }
            )
            response.raise_for_status()
        except ValueError as e:
            raise Exception("Unable to send request to the server process") from e

        if not self.interception.deserialize_response:
            try:
                return default_deserialize_client(response.content, accept_type)
            except Exception as e:
                raise Exception("Encountered error in default deserializer. Try providing a custom deserializer using @serve.deserialize_response") from e
        else:
            try:
                return self.interception.deserialize_response(response.content, accept_type)
            except Exception as e:
                raise Exception("Encountered error in @serve.deserialize_response") from e

    def destroy_server(self):
        if self.proc:
            self.proc.terminate()
            self.proc.wait()
            self.proc = None
