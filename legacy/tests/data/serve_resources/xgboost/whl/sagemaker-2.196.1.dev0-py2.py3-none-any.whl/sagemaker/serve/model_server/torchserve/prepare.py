"""Summary of MyModule.

Extended discussion of my module.
"""

from __future__ import absolute_import
from pathlib import Path
import shutil
from typing import List

from sagemaker.session import Session
from sagemaker.serve.spec.inference_spec import InferenceSpec
from sagemaker.serve.detector.dependency_manager import (
    capture_dependencies,
    prepare_wheel,
)
from sagemaker.serve.validations.check_integrity import (
    generate_secret_key,
    compute_hash,
)

from sagemaker.remote_function.core.serialization import _MetaData


def prepare_for_torchserve(
    model_path: str,
    shared_libs: List[str],
    dependencies: dict,
    session: Session,
    inference_spec: InferenceSpec = None,
) -> str:
    """This is a one-line summary of the function.

    Args:to
        model_path (str) : Argument
        shared_libs (List[]) : Argument
        dependencies (dict) : Argument
        session (Session) : Argument
        inference_spec (InferenceSpec, optional) : Argument
            (default is None)

    Returns:
        ( str ) :

    """
    model_path = Path(model_path)
    if not model_path.exists():
        model_path.mkdir()
    elif not model_path.is_dir():
        raise Exception("model_dir is not a valid directory")

    if inference_spec:
        inference_spec.prepare(str(model_path))

    code_dir = model_path.joinpath("code")
    code_dir.mkdir(exist_ok=True)

    shutil.copy2(Path(__file__).parent.joinpath("inference.py"), code_dir)
    whl_dir = model_path.joinpath("whl")
    whl_dir.mkdir(exist_ok=True)

    local_whl_path = "src/sagemaker/serve/sagemaker-2.185.1.dev0-py2.py3-none-any.whl"
    if Path(local_whl_path).resolve().is_file():
        shutil.copy(local_whl_path, whl_dir)
    else:
        prepare_wheel(session.boto_session.client("codeartifact"), whl_dir=whl_dir)

    shared_libs_dir = model_path.joinpath("shared_libs")
    shared_libs_dir.mkdir(exist_ok=True)
    for shared_lib in shared_libs:
        shutil.copy2(Path(shared_lib), shared_libs_dir)

    capture_dependencies(dependencies=dependencies, work_dir=code_dir)

    secret_key = generate_secret_key()
    with open(str(code_dir.joinpath("serve.pkl")), "rb") as f:
        buffer = f.read()
    hash_value = compute_hash(buffer=buffer, secret_key=secret_key)
    with open(str(code_dir.joinpath("metadata.json")), "wb") as metadata:
        metadata.write(_MetaData(hash_value).to_json())

    return secret_key
