"""Implements class converts data from and to np.ndarray"""
from __future__ import absolute_import

import numpy as np

class TorchTensorConverter:
    """Converts torch.Tensor from and to numpy.ndarray"""
    def __init__(self) -> None:
        global torch
        import torch
    
    def convert_to_numpy(self, data: torch.Tensor) -> np.ndarray:
        """Converts torch.Tensor to numpy ndarray"""
        try:
            return data.detach().numpy()
        except Exception as e:
            raise ValueError("Unable to convert data %s to np.ndarray"%type(data)) from e
        
    def convert_from_numpy(self, data: np.ndarray) -> torch.Tensor:
        """Converts numpy ndarray to torch.Tensor"""
        try:
            return torch.from_numpy(data)
        except Exception as e:
            raise ValueError("Unable to convert data %s to torch.Tensor"%type(data)) from e
        
        
class TensorflowTensorConverter:
    """Converts tf.Tensor from and to numpy.ndarray"""
    def __init__(self) -> None:
        global tf
        import tensorflow as tf
        
    def convert_to_numpy(self, data: tf.Tensor) -> np.ndarray:
        """Converts tf.Tensor to numpy ndarray"""
        try:
            return data.numpy()
        except Exception as e:
            raise ValueError("Unable to convert data %s to np.ndarray"%type(data)) from e
        
    def convert_from_numpy(self, data: np.ndarray) -> tf.Tensor:
        """Converts numpy ndarray to torch.Tensor"""
        try:
            return tf.convert_to_tensor(data)
        except Exception as e:
            raise ValueError("Unable to convert data %s to tf.Tensor"%type(data)) from e
        
        
class NumpyConverter:
    """A dummy class to make sure the converter interface is aligned"""
    def convert_to_numpy(self, data: np.ndarray) -> np.ndarray:
        """Placeholder docstring"""
        return data
    def convert_from_numpy(self, data: np.ndarray) -> np.ndarray:
        """Placeholder docstring"""
        return data
    
    
class ListConverter:
    """Converts python list from and to numpy.ndarray"""
    def convert_to_numpy(self, data: list) -> np.ndarray:
        """Placeholder docstring"""
        try:
            return np.array(data)
        except Exception as e:
            raise ValueError("Unable to convert data %s to np.ndarray"%type(data)) from e
        
    def convert_from_numpy(self, data: np.ndarray) -> list:
        """Placeholder docstring"""
        try:
            return data.tolist()
        except Exception as e:
            raise ValueError("Unable to convert data %s to python list"%type(data)) from e
