"""Summary of MyModule.

Extended discussion of my module.
"""
from __future__ import absolute_import
from pathlib import Path
import logging

from sagemaker.serve.builder.schema_builder import SchemaBuilder

logger = logging.getLogger(__name__)


def prepare_containers():
    # TODO: install nvidia-container-toolkit, pull sagemaker triton container
    pass


def prepare_for_triton_onnx_backend(model_path: str, model: object, schema_builder: SchemaBuilder):
    """Prepare local dir for ONNX backend

    Args:
        model_path (str): _description_
        model (object): _description_
        session (Session): _description_
    """

    # Prepare directory
    model_path = Path(model_path)
    if not model_path.exists():
        model_path.mkdir()
    elif not model_path.is_dir():
        raise Exception("model_dir is not a valid directory")

    export_path = model_path.joinpath("model_repository").joinpath("model").joinpath("1")
    if not export_path.exists():
        export_path.mkdir(parents=True)

    # Export model to onnx
    _export_model_to_onnx_format(
        model=model,
        export_path=export_path,
        schema_builder=schema_builder,
    )


def _export_model_to_onnx_format(model: object, export_path: Path, schema_builder: SchemaBuilder):
    """Export pytorch model object into onnx format"""
    logger.info("Converting pytorch model into onnx format")
    try:
        from torch.onnx import export

        export(
            model=model,
            args=schema_builder.sample_input,
            f=str(export_path.joinpath("model.onnx")),
            input_names=["input_1"],
            output_names=["output_1"],
            verbose=False,
        )

    except ModuleNotFoundError as e:
        raise ValueError("") from e
