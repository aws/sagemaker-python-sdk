"""Helper module for validating inputs for Triton model server"""
from __future__ import absolute_import
from sagemaker.serve.mode.function_pointers import Mode
from sagemaker.serve.detector.image_detector import _detect_framework_and_version, _get_model_base


def _validate_for_triton(model: object, image_uri: str, mode: Mode):
    """Validation for triton, expand this as we include more backend support with more framework"""
    if not model:
        raise ValueError(
            "Please provide a model object to ModelBuilder to serve with Triton.\
                InferenceSpec is not supported yet."
        )

    if not image_uri:
        raise ValueError(
            (
                "Autodetect container is not supported with Triton model server."
                "Please provide image_uri. For more information, see: "
                "https://github.com/aws/deep-learning-containers/blob/master/available_images.md"
                "#nvidia-triton-inference-containers-sm-support-only"
            )
        )

    if mode != Mode.LOCAL_CONTAINER:
        raise ValueError("Only LOCAL_CONTAINER mode is supported with Triton model server.")

    framework, _ = _detect_framework_and_version(str(_get_model_base(model)))
    if framework != "pytorch":
        raise ValueError("ModelBuilder only supports pytorch with Triton")
