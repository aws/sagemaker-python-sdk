#!/bin/bash
conda=$1
env_name=$2
output_path=$3
conda remove -y -n triton_env --all
conda create -y -n triton_env --clone $env_name

source ~/$conda/etc/profile.d/conda.sh
conda activate triton_env
export PYTHONNOUSERSITE=True
conda install -c conda-forge libstdcxx-ng=12 -y
pip install cloudpickle
pip install conda-pack
rm $output_path
conda-pack -o $output_path