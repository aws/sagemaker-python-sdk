PACK_SCRIPT = (
    "conda create -y -n triton_env python=3.8 && "
    "source ~/{conda}/etc/profile.d/conda.sh && "
    "conda activate triton_env && "
    "export PYTHONNOUSERSITE=True && "
    "pip install conda-pack && "
    "pip install -r {requirements_path} &&"
    "conda-pack -o {output_path}"
)
