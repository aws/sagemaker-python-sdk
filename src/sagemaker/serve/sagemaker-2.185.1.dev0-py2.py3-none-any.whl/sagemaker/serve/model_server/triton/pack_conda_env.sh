#!/bin/bash
conda=$1
env_name=$2
output_path=$3

source ~/$conda/etc/profile.d/conda.sh
export PYTHONNOUSERSITE=True
rm $output_path
conda-pack -o $output_path